

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

public class Scenario3 {

	public static void main(String[] args) throws Exception {
		//System.setProperty("webdriver.ie.driver","C:/Program Files (x86)/Mozilla Firefox/firefox.exe");
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type", 1);
		profile.setPreference("network.proxy.http", "chnproxy.igate.com");
		profile.setPreference("network.proxy.http_port", 8080);
		profile.setPreference("network.proxy.ssl", "chnproxy.igate.com");
		profile.setPreference("network.proxy.ssl_port", 8080);
		FirefoxDriver driver = new FirefoxDriver(profile);
		driver.manage().window().maximize();
		
	//Part 1: Launch Application	
		driver.get("http://demo.opencart.com/");
		
		File file=new File("C:\\Users\\subhasbh\\Desktop\\PLP_Team2\\Automation\\data.xlsx");
		FileInputStream ab=new FileInputStream(file);
		XSSFWorkbook wb=new XSSFWorkbook(ab);
		
		XSSFSheet sheet=wb.getSheetAt(0);
		String username=sheet.getRow(1).getCell(0).getStringCellValue();
		String password=sheet.getRow(1).getCell(1).getStringCellValue();
		
	//Part 2: Login
		
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/a/span[1]")).click();		//My Account
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[2]/a")).click();		//Login
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(".//*[@id='input-email']")).sendKeys(username);		//Email-id
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(".//*[@id='input-password']")).sendKeys(password);		//Password
		Thread.sleep(2000);

		driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/div/form/input")).click();		//Submit
		Thread.sleep(2000);
		
	//Part 3. Desktop Tab (First Product)
		
		//1. Verify Desktops tab
		if(driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/a")).isDisplayed())
        {
        	System.out.println("Desktops tab is present");
        	System.out.println("-------------------------------\n");
        }
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/div/a")).click();
		
		//2. Verify Mac option in Desktops drop down list
		if(driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/div/div/ul/li[2]/a")).isDisplayed())
		{
		     System.out.println("Mac option is present");
		     System.out.println("-------------------------------\n");
		}
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/a")).click();
		
		
		//3. Verify List view in Mac option of Desktops drop down list
		if(driver.findElement(By.xpath(".//*[@id='list-view']")).isDisplayed())
		{
		     System.out.println("List View icon is present");
		     System.out.println("-------------------------------\n");
		}
		driver.findElement(By.xpath(".//*[@id='list-view']")).click();
		Thread.sleep(1000);

		//4. Verify Grid view in Mac option of Desktops drop down list
		if(driver.findElement(By.xpath(".//*[@id='grid-view']")).isDisplayed())
		{
		     System.out.println("Grid View icon is present");
		     System.out.println("-------------------------------\n");
		}
		driver.findElement(By.xpath(".//*[@id='grid-view']")).click();
		Thread.sleep(1000);
		
		//4. To goto iPod Classic product page 
		driver.findElement(By.xpath(".//*[@id='content']/div[4]/div[6]/div/div[2]/div[1]/h4/a")).click();
		System.out.println("iPod Classic page is displayed");
		System.out.println("-------------------------------\n");
		
		//5. To add the product to Wishlist
		driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/div[1]/button[1]")).click();
		System.out.println("product is added to wishlist");
		System.out.println("-------------------------------\n");
		
		Thread.sleep(4000);
		//6 Verify Success message after product is added to Wishlist

		String  actualSuccessMsg= driver.findElement(By.xpath(".//*[@id='product-product']/div[1]")).getText();
		String expectedSuccessMsg="Success: You have added iPod Classic to your wish list!\n�";
		if(expectedSuccessMsg.contains(actualSuccessMsg)){
			System.out.println("Success message add to wishlist is verified");
			System.out.println("-------------------------------\n");
		}
		else{
			System.out.println("Success message add to wishlist is not verified");
			System.out.println("-------------------------------\n");
		}
		Thread.sleep(1000);		
		
		//7 Add Product to cart
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
		Thread.sleep(1000);
		System.out.println("product is added to cart");
		System.out.println("-------------------------------\n");
		Thread.sleep(4000);
		//8. Verify Success message after product is added to cart
		String  actualSuccessMsg1= driver.findElement(By.xpath(".//*[@id='product-product']/div[1]")).getText();
		String expectedSuccessMsg1="Success: You have added iPod Classic to your shopping cart!\n�";
		if(actualSuccessMsg1.contains(expectedSuccessMsg1)){
			System.out.println("Success message add to cart is verified");
			System.out.println("-------------------------------\n");
		}
		else{
			System.out.println("Success message add to cart is not verified");
			System.out.println("-------------------------------\n");
		}
		Thread.sleep(1000);
		
		//9. Open Shoping cart page
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[4]/a/span")).click();
		Thread.sleep(1000);
		System.out.println("Shoping cart page is displayed");
		System.out.println("-------------------------------\n");
		
		
		
		//10 Give quantity as 3
		driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[4]/div/input")).clear();
		driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[4]/div/input")).sendKeys("3");;
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[4]/div/span/button[1]")).click();
		Thread.sleep(4000);
		//11 Verify message for update
		String actualSuccessMsg2=driver.findElement(By.xpath(".//*[@id='checkout-cart']/div[1]")).getText();
		String expectedSuccessMsg2="Success: You have modified your shopping cart!\n�";
		if(actualSuccessMsg2.contains(expectedSuccessMsg2)){
			System.out.println("Success update message is verified");
			System.out.println("-------------------------------\n");
		}
		else{
			System.out.println("Success update message is not verified");
			System.out.println("-------------------------------\n");
		}
		Thread.sleep(3000);
		
		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[1]/a")).click();
		Thread.sleep(1000);
	}
}
